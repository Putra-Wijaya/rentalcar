<!-- All Custom Aneh -->
<br><br><br><br>

<div class="scroll-top">
	<img src="<?php echo base_url() ?>assets/sq.png" alt="">
</div>
<div class="card-body">
</div>


<footer>
	<div class="waves">
		<div class="wave" id="wave1"></div>
		<div class="wave" id="wave2"></div>
		<div class="wave" id="wave3"></div>
		<div class="wave" id="wave4"></div>
	</div>



<ul class="social_icon">
		<li><a href="https://www.google.com/maps/place/SF3+PANCING/@-6.2727145,106.9292618,16.7z/data=!4m6!3m5!1s0x2e698d3ea96c944f:0x17060aa15967723a!8m2!3d-6.2727527!4d106.9317853!16s%2Fg%2F11f03m7v9b?entry=ttu"><ion-icon name="location-outline"></ion-icon></a></li>
		<li><a href="https://api.whatsapp.com/send?phone=6285156072370"><ion-icon name="logo-whatsapp"></ion-icon></a></li>
		<li><a href="https://www.instagram.com/nusa.rc/"><ion-icon name="logo-instagram"></ion-icon></a> </li>
	</ul>
	

		<ul class="meni">
			<li><a class="active" href="<?php echo base_url('customer/dashboard') ?>">Home</a></li>
			<li><a href="<?php echo base_url('customer/tentang') ?>">About</a></li>
			<li><a href="<?php echo base_url('customer/data_mobil') ?>">Car</a></li>
			
		</ul>

	
	<p>@2024 Nusa Rent Car | All Right Reserved</p>

</footer>


<!-- Javascript -->
	<script>
		$(".menuu-btn").click(function () {
		$(".navbar1 .menuu").toggleClass("active");
		$(".menuu-btn i").toggleClass("active");
	});

	</script>
    <script src="<?php echo base_url() ?>assets/assets_shop/js/jquery-3.2.1.min.js"></script>
    <script src="<?php echo base_url() ?>assets/assets_shop/js/jquery-migrate.min.js"></script>
    <script src="<?php echo base_url() ?>assets/assets_shop/js/popper.min.js"></script>
    <script src="<?php echo base_url() ?>assets/assets_shop/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/gijgo.js"></script>
    <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/vegas.min.js"></script>
    <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/isotope.min.js"></script>
    <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/owl.carousel.min.js"></script>
    <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/waypoints.min.js"></script>
    <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/counterup.min.js"></script>
    <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/mb.YTPlayer.js"></script>
    <script src="<?php echo base_url() ?>assets/assets_shop/js/plugins/magnific-popup.min.js"></script>
    <script src="<?php echo base_url() ?>assets/assets_shop/js/main.js"></script>


	<script src="assets/assets_custom/js/jquery.min.js"></script>
    <script src="assets/assets_custom/js/popper.min.js"></script>
    <script src="assets/assets_custom/js/bootstrap.bundle.min.js"></script>
    <script src="assets/assets_custom/js/jquery-3.0.0.min.js"></script>
    <script src="assets/assets_custom/js/plugin.js"></script>
    <script src="assets/assets_custom/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="assets/assets_custom/js/custom.js"></script>
    <script src="assets/assets_custom/js/owl.carousel.js"></script>
    <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>

<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
</html>
